<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\table;

Route::get('/', function () {
    return view('welcome');
});

Route::get('table/{cle}',[Table::class,'funTab'])->wherenumber('cle');
