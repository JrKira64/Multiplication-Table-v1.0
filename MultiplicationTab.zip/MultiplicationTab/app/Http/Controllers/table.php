<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class table extends Controller
{
    public function funTab($cle){

        $tabInt = [
            1=>1,
            2=>2,
            3=>3,
            4=>4,
            5=>5,
            6=>6,
            7=>7,
            8=>8,
            9=>9
        ];

        $tab = $tabInt[$cle] ?? 'Entrez une valeur comprise entre 0 et 9' ;

        return view('Tab/Table',[
            'tab'=>$tab
        ]);

    }
}
