# MultiplicationTab V01
 multiplication table through views with Blade
